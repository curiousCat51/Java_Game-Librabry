class Life extends WorldObject{
  NormalImage[] images;
  
  String iP;
  
  Life(int grid_x, int grid_y){
    super(WorldTypes.LIFE, grid_x, grid_y);
    
    images = new NormalImage[7];
    
    for(int i = 0; i < 7; i++){
      iP = "data/images/Visuals/heart_" + (i + 1);
      images[i] = new NormalImage(iP);
    }
    
    setImageContainer(images[0]);
  }
  
  void damage(){
    
    for(int i = 0; i < 6; i++){
      setImageContainer(images[i + 1]);
    }
    
    lifes--;
    
  }
}
